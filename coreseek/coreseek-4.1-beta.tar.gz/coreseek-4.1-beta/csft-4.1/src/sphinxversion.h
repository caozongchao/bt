#define SPH_SVN_TAG ""
#define SPH_SVN_REV 2922
#define SPH_SVN_REVSTR "2922"
#define SPH_SVN_TAGREV "r2922"
