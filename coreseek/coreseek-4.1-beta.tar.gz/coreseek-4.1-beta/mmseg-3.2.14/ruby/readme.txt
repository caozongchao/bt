tested on win32 only

1 You MUST copy uni.lib from the 'src' directory before running test.rb
2 I changed the libcss complie mode from 'multi-thread' into 'multi-thread dll', this might be break sphinx's build.