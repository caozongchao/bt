#searchbay
A Bootstrap template for a torrent website



##About
This project is nothing more than a simple Bootstrap template for what could be a torrent search engine website. 



##Made using
* Bootstrap v3.3.1 (http://getbootstrap.com)
* Font Awesome 4.2.0 (http://fontawesome.io)
* Bootsnippet (http://bootsnipp.com)



##License
This project is available using the MIT license. Feel free to enhance it or even make you own torrent site using this template!